import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    container: { center: true, padding: { DEFAULT: "1.25rem", md: "2rem" }, screens: { "2xl": "1280px" } },
    extend: {
      colors: {
        navy: { DEFAULT: "#071A36", 950: "#040F21", 900: "#071A36", 800: "#0B2448" },
        royal: { DEFAULT: "#0866F5", 600: "#0657D2" },
        electric: { DEFAULT: "#00B8FF" },
        slate: { DEFAULT: "#17243A", ink: "#17243A", muted: "#5B6B82", line: "#E2E8F1" },
        mist: { DEFAULT: "#F5F8FC" },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-manrope)", "var(--font-inter)", "sans-serif"],
      },
      letterSpacing: { tightest: "-0.04em" },
      boxShadow: {
        card: "0 1px 2px rgba(7,26,54,.04), 0 12px 32px -12px rgba(7,26,54,.12)",
        lift: "0 2px 4px rgba(7,26,54,.05), 0 24px 48px -16px rgba(8,102,245,.25)",
        glow: "0 0 0 1px rgba(0,184,255,.25), 0 10px 40px -10px rgba(0,184,255,.45)",
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg,#0866F5 0%,#00B8FF 100%)",
        "grid-faint":
          "linear-gradient(rgba(255,255,255,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px)",
      },
      keyframes: {
        drift: { "0%,100%": { transform: "translate3d(0,0,0)" }, "50%": { transform: "translate3d(2%,-3%,0)" } },
        marquee: { from: { transform: "translateX(0)" }, to: { transform: "translateX(-50%)" } },
      },
      animation: { drift: "drift 18s ease-in-out infinite", marquee: "marquee 40s linear infinite" },
    },
  },
  plugins: [],
};
export default config;
