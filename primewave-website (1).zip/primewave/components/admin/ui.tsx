import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageTitle({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 className="text-3xl font-bold text-navy">{title}</h1>
        {sub && <p className="mt-1 text-slate-muted">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-2xl border border-slate-line bg-white p-6 shadow-card", className)}>{children}</div>;
}

const tones: Record<string, string> = {
  new: "bg-electric/10 text-[#0077A8]", contacted: "bg-royal/10 text-royal", qualified: "bg-indigo-100 text-indigo-700",
  proposal: "bg-amber-100 text-amber-800", negotiation: "bg-amber-100 text-amber-800", won: "bg-emerald-100 text-emerald-700",
  completed: "bg-emerald-100 text-emerald-700", lost: "bg-slate-100 text-slate-600", cancelled: "bg-slate-100 text-slate-600",
  no_show: "bg-red-100 text-red-700", scheduled: "bg-royal/10 text-royal", in_progress: "bg-royal/10 text-royal",
  planning: "bg-electric/10 text-[#0077A8]", review: "bg-amber-100 text-amber-800", on_hold: "bg-slate-100 text-slate-600",
  lead: "bg-electric/10 text-[#0077A8]",
};
export function Badge({ value }: { value: string }) {
  return <span className={cn("inline-block rounded-full px-2.5 py-1 text-xs font-semibold capitalize", tones[value] ?? "bg-mist text-slate-ink")}>{value.replace(/_/g, " ")}</span>;
}

export function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return <label className={cn("block", className)}><span className="mb-1.5 block text-sm font-medium text-slate-ink">{label}</span>{children}</label>;
}

export const input = "w-full rounded-lg border border-slate-line bg-white px-3 py-2 text-sm focus:border-royal focus:outline-none focus:ring-2 focus:ring-royal/15";
export const btn = "inline-flex items-center justify-center gap-2 rounded-lg bg-royal px-4 py-2 text-sm font-semibold text-white transition hover:bg-royal-600 disabled:opacity-60";
export const btnGhost = "inline-flex items-center justify-center gap-2 rounded-lg border border-slate-line px-4 py-2 text-sm font-semibold text-slate-ink transition hover:border-royal hover:text-royal";

export function Empty({ children }: { children: ReactNode }) {
  return <p className="rounded-xl border border-dashed border-slate-line p-8 text-center text-sm text-slate-muted">{children}</p>;
}

export function Table({ head, children }: { head: string[]; children: ReactNode }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-line bg-white shadow-card">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="border-b border-slate-line bg-mist text-xs uppercase tracking-wider text-slate-muted">
          <tr>{head.map((h) => <th key={h} scope="col" className="px-4 py-3 font-semibold">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-slate-line">{children}</tbody>
      </table>
    </div>
  );
}
export const td = "px-4 py-3 align-middle";

/** Collapsible "create" panel using native <details> — no client JS needed. */
export function NewPanel({ label, children }: { label: string; children: ReactNode }) {
  return (
    <details className="group mb-8 rounded-2xl border border-slate-line bg-white shadow-card">
      <summary className="flex cursor-pointer list-none items-center justify-between px-6 py-4 font-semibold text-navy">
        {label}<span className="text-royal transition-transform group-open:rotate-45">＋</span>
      </summary>
      <div className="border-t border-slate-line p-6">{children}</div>
    </details>
  );
}
