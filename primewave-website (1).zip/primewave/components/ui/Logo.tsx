import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

export function Logo({ dark = false, className }: { dark?: boolean; className?: string }) {
  return (
    <Link href="/" aria-label="PrimeWave Marketing Agency — home" className={cn("flex items-center gap-2.5", className)}>
      <Image src="/images/primewave-mark.png" alt="" width={36} height={36} priority className="h-9 w-9" />
      <span className="leading-none">
        <span className={cn("block font-display text-[17px] font-extrabold tracking-tight", dark ? "text-white" : "text-navy")}>
          PrimeWave
        </span>
        <span className={cn("block text-[9.5px] font-semibold uppercase tracking-[0.28em]", dark ? "text-electric" : "text-royal")}>
          Marketing Agency
        </span>
      </span>
    </Link>
  );
}
