import { ImageResponse } from "next/og";

export const alt = "PrimeWave Marketing Agency — Turning Digital Potential Into Business Growth.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OgImage() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 80,
        background: "radial-gradient(circle at 15% 10%, #0866F5 0%, #071A36 55%)", color: "white", fontFamily: "sans-serif" }}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 34, fontWeight: 800 }}>PrimeWave</div>
          <div style={{ fontSize: 16, letterSpacing: 6, color: "#00B8FF" }}>MARKETING AGENCY</div>
        </div>
        <div style={{ fontSize: 72, fontWeight: 800, lineHeight: 1.05, maxWidth: 950 }}>Turning Digital Potential Into Business Growth.</div>
        <div style={{ fontSize: 26, color: "#9FC9FF", letterSpacing: 4 }}>STRATEGY. INNOVATION. GROWTH.</div>
      </div>
    ),
    size
  );
}
